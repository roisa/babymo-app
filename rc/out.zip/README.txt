Baby Mo story narration (1 approved takes).
One WAV per page: www/story-voice/<lang>/<story>/<page>.wav (00 = title, 05q = the quote on page 5).
rekam-manifest.json lists each take with its text. Upload this ZIP to Google Drive and tell Claude its name.
